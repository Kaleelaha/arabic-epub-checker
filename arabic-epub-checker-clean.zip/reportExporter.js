export const LABELS = { missing: 'Missing in EPUB', extra: 'Extra in EPUB', changed: 'Changed text', spelling: 'Possible spelling issue' };

export const formatDifference = (d) =>
  `[${d.chapter}] ${LABELS[d.category]}\nPDF: ${d.before} ${d.pdfText || '—'} ${d.after}\nEPUB: ${d.before} ${d.epubText || '—'} ${d.after}`;
export const formatAll = (list) => list.map(formatDifference).join('\n\n');

/** Plain-language correction instructions grouped by chapter. */
export function correctionReport(list) {
  const by = {};
  list.forEach((d) => (by[d.chapter] ||= []).push(d));
  return Object.entries(by).map(([ch, items]) => `== ${ch} ==\n` + items.map((d) => {
    const at = d.before ? ` (after: «${d.before.split(' ').slice(-4).join(' ')}»)` : '';
    if (d.category === 'missing') return `• Insert «${d.pdfText}»${at}`;
    if (d.category === 'extra') return `• Remove «${d.epubText}»${at}`;
    return `• Replace «${d.epubText}» with «${d.pdfText}»${at}${d.category === 'spelling' ? ' [possible spelling issue – verify]' : ''}`;
  }).join('\n')).join('\n\n');
}

export async function copyText(text) {
  try { await navigator.clipboard.writeText(text); }
  catch { const t = document.createElement('textarea'); t.value = text; document.body.appendChild(t); t.select(); document.execCommand('copy'); t.remove(); }
}

/** UTF-8 CSV with BOM so Excel reads Arabic correctly. */
export function downloadCSV(list) {
  const q = (v) => `"${String(v).replace(/"/g, '""')}"`;
  const rows = [['Chapter', 'Category', 'PDF text', 'EPUB text', 'Context before', 'Context after']]
    .concat(list.map((d) => [d.chapter, LABELS[d.category], d.pdfText, d.epubText, d.before, d.after]));
  const url = URL.createObjectURL(new Blob(['\uFEFF' + rows.map((r) => r.map(q).join(',')).join('\r\n')], { type: 'text/csv;charset=utf-8' }));
  const a = Object.assign(document.createElement('a'), { href: url, download: 'epub-differences.csv' });
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000); // release the temporary URL
}
